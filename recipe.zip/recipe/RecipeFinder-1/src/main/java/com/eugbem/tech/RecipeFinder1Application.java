package com.eugbem.tech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeFinder1Application {

	public static void main(String[] args) {
		SpringApplication.run(RecipeFinder1Application.class, args);
	}

}
