package com.eugbem.tech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeFinApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipeFinApplication.class, args);
	}

}
